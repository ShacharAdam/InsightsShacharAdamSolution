// __tests__/main.test.js
const {
  extractCapacityFromName,
  extractGenerationFromName,
  extractColorFromName,
} = require("../nameManipulation.js");




// List of possible colors that might appear in the phone name.
const fullColorList = [
  `AliceBlue`,
  `AntiqueWhite`,
  `Aqua`,
  `Aquamarine`,
  `Azure`,
  `Beige`,
  `Bisque`,
  `Black`,
  `BlanchedAlmond`,
  `Blue`,
  `BlueViolet`,
  `Brown`,
  `BurlyWood`,
  `CadetBlue`,
  `Chartreuse`,
  `Chocolate`,
  `Coral`,
  `CornflowerBlue`,
  `Cornsilk`,
  `Crimson`,
  `Cyan`,
  `DarkBlue`,
  `DarkCyan`,
  `DarkGoldenRod`,
  `DarkGray`,
  `DarkGrey`,
  `DarkGreen`,
  `DarkKhaki`,
  `DarkMagenta`,
  `DarkOliveGreen`,
  `Darkorange`,
  `DarkOrchid`,
  `DarkRed`,
  `DarkSalmon`,
  `DarkSeaGreen`,
  `DarkSlateBlue`,
  `DarkSlateGray`,
  `DarkSlateGrey`,
  `DarkTurquoise`,
  `DarkViolet`,
  `DeepPink`,
  `DeepSkyBlue`,
  `DimGray`,
  `DimGrey`,
  `DodgerBlue`,
  `FireBrick`,
  `FloralWhite`,
  `ForestGreen`,
  `Fuchsia`,
  `Gainsboro`,
  `GhostWhite`,
  `Gold`,
  `GoldenRod`,
  `Gray`,
  `Grey`,
  `Green`,
  `GreenYellow`,
  `HoneyDew`,
  `HotPink`,
  `IndianRed`,
  `Indigo`,
  `Ivory`,
  `Khaki`,
  `Lavender`,
  `LavenderBlush`,
  `LawnGreen`,
  `LemonChiffon`,
  `LightBlue`,
  `LightCoral`,
  `LightCyan`,
  `LightGoldenRodYellow`,
  `LightGray`,
  `LightGrey`,
  `LightGreen`,
  `LightPink`,
  `LightSalmon`,
  `LightSeaGreen`,
  `LightSkyBlue`,
  `LightSlateGray`,
  `LightSlateGrey`,
  `LightSteelBlue`,
  `LightYellow`,
  `Lime`,
  `LimeGreen`,
  `Linen`,
  `Magenta`,
  `Maroon`,
  `MediumAquaMarine`,
  `MediumBlue`,
  `MediumOrchid`,
  `MediumPurple`,
  `MediumSeaGreen`,
  `MediumSlateBlue`,
  `MediumSpringGreen`,
  `MediumTurquoise`,
  `MediumVioletRed`,
  `MidnightBlue`,
  `MintCream`,
  `MistyRose`,
  `Moccasin`,
  `NavajoWhite`,
  `Navy`,
  `OldLace`,
  `Olive`,
  `OliveDrab`,
  `Orange`,
  `OrangeRed`,
  `Orchid`,
  `PaleGoldenRod`,
  `PaleGreen`,
  `PaleTurquoise`,
  `PaleVioletRed`,
  `PapayaWhip`,
  `PeachPuff`,
  `Peru`,
  `Pink`,
  `Plum`,
  `PowderBlue`,
  `Purple`,
  `Red`,
  `RosyBrown`,
  `RoyalBlue`,
  `SaddleBrown`,
  `Salmon`,
  `SandyBrown`,
  `SeaGreen`,
  `SeaShell`,
  `Sienna`,
  `Silver`,
  `SkyBlue`,
  `SlateBlue`,
  `SlateGray`,
  `SlateGrey`,
  `Snow`,
  `SpringGreen`,
  `SteelBlue`,
  `Tan`,
  `Teal`,
  `Thistle`,
  `Tomato`,
  `Turquoise`,
  `Violet`,
  `Wheat`,
  `White`,
  `WhiteSmoke`,
  `Yellow`,
  `YellowGreen`,
];

describe("extractCapacityFromName", () => {
  test("extracts capacity correctly when present", () => {
    expect(extractCapacityFromName("Phone, 128GB, Black")).toBe("128 GB");
    expect(extractCapacityFromName("Apple iPhone 12 Mini, 256GB, Blue	")).toBe(
      "256 GB"
    );
  });

  test("returns empty string when capacity info is not present", () => {
    expect(extractCapacityFromName("Phone, No Capacity Info")).toBe("");
    expect(extractCapacityFromName("Samsung Galaxy ZGBC Fold2")).toBe("");
    expect(extractCapacityFromName("Samsung Galaxy ZGB2C Fold2")).toBe("");
  });

  test("handles different formats and cases of capacity information", () => {
    expect(extractCapacityFromName("Macbook 20mm, 128 gb, Silver")).toBe(
      "128 GB"
    );
    expect(extractCapacityFromName("Phone, 256 Gb, Red")).toBe("256 GB");
    expect(extractCapacityFromName("Phone, 512 GB, Gold")).toBe("512 GB");
  });

  test("Capacity measured in other units", () => {
    expect(extractCapacityFromName("Phone, 256 MB, Silver")).toBe("256 MB");
    expect(extractCapacityFromName("Apple MacBook Pro 16, 1 TB, Green")).toBe(
      "1 TB"
    );
  });
});

describe("extractGenerationFromName", () => {
  test("extracts generation correctly when present", () => {
    expect(extractGenerationFromName("Phone 4th Generation")).toBe("4th");
    expect(extractGenerationFromName("Phone 1st Gen")).toBe("1st");
  });

  test("returns empty string when generation info is not present", () => {
    expect(extractGenerationFromName("Apple AirPods 3rd edition")).toBe("");
    expect(extractGenerationFromName("Apple iPad Air")).toBe("");
  });

  test("handles different formats of generation information", () => {
    expect(extractGenerationFromName("Phone Generation 10th")).toBe("10th");
    expect(extractGenerationFromName("Phone gen 2nd")).toBe("2nd");
  });
});

describe("extractColorFromName", () => {
  test("extracts color correctly when present", () => {
    expect(extractColorFromName("Phone, Black Edition", fullColorList)).toBe(
      "Black"
    );
    expect(extractColorFromName("Phone, Aqua Blue", fullColorList)).toBe(
      "Aqua"
    );
  });

  test("returns empty string when color info is not present", () => {
    expect(
      extractColorFromName("Google Pixel 6 Pro, No Color Info", fullColorList)
    ).toBe("");
    expect(extractColorFromName("Beats Studio3 Wireless", fullColorList)).toBe(
      ""
    );
    expect(extractColorFromName("Phone with Red Strap", fullColorList)).toBe(
      ""
    );
  });

  test("handles different formats and cases of color information", () => {
    expect(extractColorFromName("Phone, Aqua blue", fullColorList)).toBe(
      "Aqua"
    );
    expect(extractColorFromName("Phone, Maroon Edition", fullColorList)).toBe(
      "Maroon"
    );
  });
});
