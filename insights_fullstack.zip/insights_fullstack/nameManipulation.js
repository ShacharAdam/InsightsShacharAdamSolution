/**
 * Extracts generation information from the phone name string.
 * @param {string} name - The name of the phone.
 * @returns {string} - The extracted generation or an empty string if not found.
 */
function extractGenerationFromName(name) {
  let parts = name.split(" ");
  let generationPart = parts.find((part, index, arr) => {
    if (part.match(/\d+(th|st|nd|rd)/)) {
      // Check if the previous or next word is "gen" or "generation" in any case
      if (
        arr[index - 1]?.toLowerCase() === "gen" ||
        arr[index + 1]?.toLowerCase() === "gen" ||
        arr[index - 1]?.toLowerCase() === "generation" ||
        arr[index + 1]?.toLowerCase() === "generation"
      ) {
        return true;
      }
    }
    return false;
  });

  return generationPart || "";
}

/**
 * Extracts capacity (in GB, MB, or TB) from the phone name string.
 * @param {string} name - The name of the phone.
 * @returns {string} - The extracted capacity or an empty string if not found.
 */
function extractCapacityFromName(name) {
  // Match patterns like '64GB', '64 GB', 'Capacity: 64GB', '64MB', '64 MB', '64TB', '64 TB'
  let capacityPattern = /\b(\d+)\s*(GB|MB|TB)\b/i; // Matches whole word followed by GB, MB, or TB preceded by digits

  // Search for the pattern in the name
  let match = name.match(capacityPattern);
  if (match) {
    return match[1] + " " + match[2].toUpperCase(); // Return the matched digits followed by the unit in uppercase
  }

  return "";
}

// List of possible colors that might appear in the phone name.
const fullColorList = [
  `AliceBlue`,
  `AntiqueWhite`,
  `Aqua`,
  `Aquamarine`,
  `Azure`,
  `Beige`,
  `Bisque`,
  `Black`,
  `BlanchedAlmond`,
  `Blue`,
  `BlueViolet`,
  `Brown`,
  `BurlyWood`,
  `CadetBlue`,
  `Chartreuse`,
  `Chocolate`,
  `Coral`,
  `CornflowerBlue`,
  `Cornsilk`,
  `Crimson`,
  `Cyan`,
  `DarkBlue`,
  `DarkCyan`,
  `DarkGoldenRod`,
  `DarkGray`,
  `DarkGrey`,
  `DarkGreen`,
  `DarkKhaki`,
  `DarkMagenta`,
  `DarkOliveGreen`,
  `Darkorange`,
  `DarkOrchid`,
  `DarkRed`,
  `DarkSalmon`,
  `DarkSeaGreen`,
  `DarkSlateBlue`,
  `DarkSlateGray`,
  `DarkSlateGrey`,
  `DarkTurquoise`,
  `DarkViolet`,
  `DeepPink`,
  `DeepSkyBlue`,
  `DimGray`,
  `DimGrey`,
  `DodgerBlue`,
  `FireBrick`,
  `FloralWhite`,
  `ForestGreen`,
  `Fuchsia`,
  `Gainsboro`,
  `GhostWhite`,
  `Gold`,
  `GoldenRod`,
  `Gray`,
  `Grey`,
  `Green`,
  `GreenYellow`,
  `HoneyDew`,
  `HotPink`,
  `IndianRed`,
  `Indigo`,
  `Ivory`,
  `Khaki`,
  `Lavender`,
  `LavenderBlush`,
  `LawnGreen`,
  `LemonChiffon`,
  `LightBlue`,
  `LightCoral`,
  `LightCyan`,
  `LightGoldenRodYellow`,
  `LightGray`,
  `LightGrey`,
  `LightGreen`,
  `LightPink`,
  `LightSalmon`,
  `LightSeaGreen`,
  `LightSkyBlue`,
  `LightSlateGray`,
  `LightSlateGrey`,
  `LightSteelBlue`,
  `LightYellow`,
  `Lime`,
  `LimeGreen`,
  `Linen`,
  `Magenta`,
  `Maroon`,
  `MediumAquaMarine`,
  `MediumBlue`,
  `MediumOrchid`,
  `MediumPurple`,
  `MediumSeaGreen`,
  `MediumSlateBlue`,
  `MediumSpringGreen`,
  `MediumTurquoise`,
  `MediumVioletRed`,
  `MidnightBlue`,
  `MintCream`,
  `MistyRose`,
  `Moccasin`,
  `NavajoWhite`,
  `Navy`,
  `OldLace`,
  `Olive`,
  `OliveDrab`,
  `Orange`,
  `OrangeRed`,
  `Orchid`,
  `PaleGoldenRod`,
  `PaleGreen`,
  `PaleTurquoise`,
  `PaleVioletRed`,
  `PapayaWhip`,
  `PeachPuff`,
  `Peru`,
  `Pink`,
  `Plum`,
  `PowderBlue`,
  `Purple`,
  `Red`,
  `RosyBrown`,
  `RoyalBlue`,
  `SaddleBrown`,
  `Salmon`,
  `SandyBrown`,
  `SeaGreen`,
  `SeaShell`,
  `Sienna`,
  `Silver`,
  `SkyBlue`,
  `SlateBlue`,
  `SlateGray`,
  `SlateGrey`,
  `Snow`,
  `SpringGreen`,
  `SteelBlue`,
  `Tan`,
  `Teal`,
  `Thistle`,
  `Tomato`,
  `Turquoise`,
  `Violet`,
  `Wheat`,
  `White`,
  `WhiteSmoke`,
  `Yellow`,
  `YellowGreen`,
];

/**
 * Extracts color from the phone name string based on a predefined list of colors.
 * Excludes certain words like "strap" from consideration.
 * @param {string} name - The name of the phone.
 * @param {array} colorList - List of predefined colors.
 * @returns {string} - The extracted color or an empty string if not found.
 */
function extractColorFromName(name, colorList) {
  let lowercaseName = name.toLowerCase();

  // Define excluded words (e.g., strap, edition, etc.)
  const excludedWords = ["strap"];

  for (let color of colorList) {
    let lowercaseColor = color.toLowerCase();
    let colorIndex = lowercaseName.indexOf(lowercaseColor);

    if (colorIndex !== -1) {
      // Check if any excluded word comes after the color
      let foundExcludedWord = false;
      for (let word of excludedWords) {
        let wordIndex = lowercaseName.indexOf(word);
        if (wordIndex !== -1 && wordIndex > colorIndex) {
          foundExcludedWord = true;
          break;
        }
      }

      if (!foundExcludedWord) {
        return color;
      }
    }
  }

  return "";
}

module.exports = {
  extractGenerationFromName,
  extractCapacityFromName,
  fullColorList,
  extractColorFromName,
};
